package com.tonghua.codex

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF17212B)
private val Green = Color(0xFF18A879)
private val Canvas = Color(0xFFF5F7F8)
private val Muted = Color(0xFF77838D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TonghuaApp() }
    }
}

@Composable
fun TonghuaApp() {
    var tab by remember { mutableStateOf(0) }
    var selectedChat by remember { mutableStateOf<String?>(null) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green, onPrimary = Color.White,
            background = Canvas, surface = Color.White,
            onBackground = Ink, onSurface = Ink
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Canvas) {
            if (selectedChat != null) {
                ChatDetail(selectedChat!!) { selectedChat = null }
            } else {
                Column(Modifier.fillMaxSize()) {
                    when (tab) {
                        0 -> MessagesScreen(onOpen = { selectedChat = it })
                        1 -> ContactsScreen()
                        2 -> DiscoverScreen()
                        else -> ProfileScreen()
                    }
                    NavigationBar(containerColor = Color.White) {
                        val items = listOf(
                            "消息" to Icons.Default.ChatBubble,
                            "联系人" to Icons.Default.People,
                            "发现" to Icons.Default.Explore,
                            "我的" to Icons.Default.Person
                        )
                        items.forEachIndexed { index, item ->
                            NavigationBarItem(
                                selected = tab == index,
                                onClick = { tab = index },
                                icon = { Icon(item.second, contentDescription = item.first) },
                                label = { Text(item.first) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, indicatorColor = Color(0xFFE3F5EE))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScreenHeader(title: String, action: String? = null) {
    Row(
        Modifier.fillMaxWidth().background(Color.White).padding(horizontal = 20.dp, vertical = 18.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
        if (action != null) Text(action, color = Green, fontSize = 14.sp)
    }
}

data class ChatItem(val name: String, val message: String, val time: String, val badge: String = "")
private val sampleChats = listOf(
    ChatItem("产品讨论组", "小林：新版首页已经更新", "11:42", "3"),
    ChatItem("林晓", "晚上一起开个视频会议？", "10:26"),
    ChatItem("通话 Codex 助手", "你好！我是你的智能助手。", "昨天"),
    ChatItem("家人", "照片收到了，很好看。", "昨天")
)

@Composable
fun MessagesScreen(onOpen: (String) -> Unit) {
    Column {
        ScreenHeader("消息", "＋")
        OutlinedTextField(
            value = "", onValueChange = {}, readOnly = true,
            placeholder = { Text("搜索聊天、联系人") },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White, focusedContainerColor = Color.White)
        )
        LazyColumn {
            items(sampleChats.size) { i ->
                val chat = sampleChats[i]
                Row(
                    Modifier.fillMaxWidth().clickable { onOpen(chat.name) }.background(Color.White)
                        .padding(horizontal = 18.dp, vertical = 15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(chat.name)
                    Spacer(Modifier.width(13.dp))
                    Column(Modifier.weight(1f)) {
                        Text(chat.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Spacer(Modifier.height(5.dp))
                        Text(chat.message, color = Muted, fontSize = 13.sp, maxLines = 1)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(chat.time, color = Muted, fontSize = 11.sp)
                        if (chat.badge.isNotEmpty()) {
                            Spacer(Modifier.height(7.dp))
                            Box(Modifier.background(Green, CircleShape).padding(horizontal = 7.dp, vertical = 2.dp)) {
                                Text(chat.badge, color = Color.White, fontSize = 10.sp)
                            }
                        }
                    }
                }
                HorizontalDivider(color = Color(0xFFF0F2F3), thickness = 0.6.dp)
            }
        }
    }
}

@Composable
fun Avatar(label: String) {
    Box(Modifier.size(50.dp).background(Color(0xFFE3F3ED), RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
        Text(label.take(1), color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ChatDetail(name: String, onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf("你好，欢迎使用通话 Codex！", "这里是本地演示会话。") }
    Column(Modifier.fillMaxSize().background(Canvas)) {
        Row(Modifier.fillMaxWidth().background(Color.White).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text(name, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 18.sp)
            IconButton(onClick = {}) { Icon(Icons.Default.Call, null, tint = Green) }
            IconButton(onClick = {}) { Icon(Icons.Default.Videocam, null, tint = Green) }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages.size) { i ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (i % 2 == 0) Arrangement.Start else Arrangement.End) {
                    Surface(color = if (i % 2 == 0) Color.White else Color(0xFFDDF5E9), shape = RoundedCornerShape(14.dp)) {
                        Text(messages[i], Modifier.padding(12.dp))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().background(Color.White).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {}) { Icon(Icons.Default.AddCircleOutline, null, tint = Green) }
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("输入消息…") }, shape = RoundedCornerShape(24.dp), singleLine = true)
            IconButton(onClick = { if (text.isNotBlank()) { messages.add(text); text = "" } }) {
                Icon(Icons.Default.Send, null, tint = Green)
            }
        }
    }
}

@Composable
fun ContactsScreen() {
    Column {
        ScreenHeader("联系人", "添加")
        OutlinedTextField("", {}, readOnly = true, placeholder = { Text("搜索联系人") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(14.dp))
        listOf("新的朋友", "群聊", "林晓", "小林", "家人").forEach {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Avatar(it); Spacer(Modifier.width(14.dp)); Text(it, fontWeight = FontWeight.Medium)
            }
            HorizontalDivider(color = Canvas)
        }
    }
}

@Composable
fun DiscoverScreen() {
    Column {
        ScreenHeader("发现")
        listOf(
            Triple(Icons.Default.PhotoLibrary, "动态", "分享生活中的精彩瞬间"),
            Triple(Icons.Default.VideoCall, "语音与视频", "随时与朋友保持联系"),
            Triple(Icons.Default.AutoAwesome, "AI 助手", "翻译、总结与智能问答"),
            Triple(Icons.Default.Folder, "文件传输", "集中管理聊天文件")
        ).forEach { (icon, title, subtitle) ->
            Row(Modifier.fillMaxWidth().padding(top = 8.dp).background(Color.White).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Green, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(16.dp))
                Column { Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 12.sp) }
                Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
    }
}

@Composable
fun ProfileScreen() {
    Column {
        ScreenHeader("我的")
        Row(Modifier.fillMaxWidth().background(Color.White).padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(66.dp).background(Color(0xFFE3F3ED), RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, tint = Green, modifier = Modifier.size(36.dp))
            }
            Spacer(Modifier.width(16.dp))
            Column {
                Text("通话 Codex 用户", fontWeight = FontWeight.Bold, fontSize = 19.sp)
                Text("账号：尚未登录", color = Muted, fontSize = 13.sp)
            }
        }
        listOf("个人资料", "账号与安全", "隐私设置", "通用设置", "关于通话 Codex").forEach {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp).background(Color.White).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(it, Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
    }
}
